import { WebGLCapabilities } from './WebGLCapabilities';

export class WebGLExtensions {

	constructor( gl: WebGLRenderingContext );

	has( name: string ): boolean;
	init( capabilities: WebGLCapabilities ): void;
	get( name: string ): any;

}
